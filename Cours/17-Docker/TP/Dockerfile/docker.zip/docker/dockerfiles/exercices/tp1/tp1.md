## TP-2 – Dockerfile 


Créer un dossier « dossier2 ». 

Dans ce dossier, il faudra récupérer le projet sur git : https://github.com/html5up/identity 

Toujours dans ce dossier, il faudra créer un autre fichier 

«Dockerfile ». 

Remplir le fichier Dockerfile pour permettre d’afficher le contenu de la page html du projet. 

Créer une image docker à partir du dockerfile. 

Tester votre image pour voir si elle fonctionne (au travers un container). 

  

Mettez le Dockerfile dans le dossier teams dédié à cet effet. 