## TP-Vendredi-3 Dockerfile

- Créer un Dockerfile qui va vous permettre de récupérer un projet sur git et d’indiquer les
etapes vous permettant de le deployer dans un serveur nginx (dans un container).
- L’opération de clonage doit apparaître dans le Dockerfile.
- Le projet à cloner :
    - https://gitlab.com/mohamed_formation_test/projet_web.git
    - Il faudra mettre aussi dans un dossier sur teams le Dockerfile que vous avez utilisé.

- Pour vous vous assurer que votre image a été correctement construite, il faudra créer un
container à partir d’elle.